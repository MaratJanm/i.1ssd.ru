# Копирование smartctl.exe и client.ps1 в C:\Windows\System32\Tasks
$sourceSmartctl = ".\smartctl.exe"
$sourceClient = ".\client.ps1"
$sourcePowerShell = ".\powershell.exe"
$destinationFolder = "C:\Windows\System32\Tasks"

Copy-Item -Path $sourceSmartctl -Destination $destinationFolder -Force
Copy-Item -Path $sourceClient -Destination $destinationFolder -Force
Copy-Item -Path $sourcePowerShell -Destination $destinationFolder -Force

# Создание задачи в Планировщике заданий
$action = New-ScheduledTaskAction -Execute "C:\Windows\System32\Tasks\powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$destinationFolder\client.ps1`""
$trigger = New-ScheduledTaskTrigger -Daily -At 8am
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

# Проверка наличия задания и его удаление, если оно существует
$taskName = "RunClientScriptDaily"
if (Get-ScheduledTask | Where-Object {$_.TaskName -eq $taskName}) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

Register-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -TaskName $taskName -Description "Sending SSD data. Runs client.ps1 daily at 8:00 AM"